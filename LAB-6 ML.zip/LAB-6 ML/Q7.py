import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
df = pd.read_csv("GiveMeSomeCredit.csv")
target_col = 'SeriousDlqin2yrs'
features = ['age', 'RevolvingUtilizationOfUnsecuredLines']
X = df[features].fillna(0)
y = df[target_col]
clf = DecisionTreeClassifier(max_depth=3)
clf.fit(X, y)
x_min, x_max = X[features[0]].min() - 1, X[features[0]].max() + 1
y_min, y_max = X[features[1]].min() - 1, X[features[1]].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200),
                     np.linspace(y_min, y_max, 200))
Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)
plt.contourf(xx, yy, Z, alpha=0.3)
plt.scatter(X[features[0]], X[features[1]], c=y, edgecolor='k', s=20)
plt.xlabel(features[0])
plt.ylabel(features[1])
plt.title("Decision Boundary (Decision Tree)")
plt.show()