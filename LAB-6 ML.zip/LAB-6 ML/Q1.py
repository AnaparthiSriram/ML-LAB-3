import pandas as pd
import numpy as np
from math import log2
df = pd.read_csv("GiveMeSomeCredit.csv")
target_col = 'SeriousDlqin2yrs'
def equal_width_binning(series, bins=4):
    return pd.cut(series, bins=bins, labels=False)
if df[target_col].nunique() > 10:  
    df[target_col] = equal_width_binning(df[target_col])
def calculate_entropy(series):
    counts = series.value_counts()
    total = len(series)
    entropy = 0
    for count in counts:
        p = count / total
        entropy -= p * log2(p)
    return entropy
entropy_value = calculate_entropy(df[target_col])
print(f"Entropy of {target_col}: {entropy_value:.4f}")