import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

if __name__=="__main__":
    datasets={"AND":(np.array([[0,0],[0,1],[1,0],[1,1]]),np.array([0,0,0,1])),
              "XOR":(np.array([[0,0],[0,1],[1,0],[1,1]]),np.array([0,1,1,0]))}
    for name,(X,y) in datasets.items():
        clf=MLPClassifier(hidden_layer_sizes=(2,),activation='logistic',
                          solver='sgd',learning_rate_init=0.05,
                          max_iter=5000,random_state=42)
        clf.fit(X,y); preds=clf.predict(X)
        print(f"{name} Gate -> Accuracy:",accuracy_score(y,preds),"Predictions:",preds)
