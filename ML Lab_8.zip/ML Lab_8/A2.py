import numpy as np
import matplotlib.pyplot as plt
def summation_unit(x: np.ndarray, w: np.ndarray) -> float:
    return float(np.dot(x, w))

def step_activation(x):
    return np.where(x >= 0, 1.0, 0.0)

def sum_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    e = y_true - y_pred
    return float(np.sum(e**2))

def add_bias_column(X):
    return np.hstack([np.ones((X.shape[0], 1)), X])
def perceptron_train(X, y, w_init, lr=0.05, max_epochs=1000, convergence_error=0.002):
    Xb = add_bias_column(X)
    w = w_init.copy()
    errors = []

    for epoch in range(1, max_epochs+1):
        outputs = []
        for xi, target in zip(Xb, y):
            net = summation_unit(xi, w)
            out = step_activation(net)
            outputs.append(out)
            # Perceptron weight update
            w += lr * (target - out) * xi
        sse = sum_squared_error(y, np.array(outputs))
        errors.append(sse)
        if sse <= convergence_error:
            break
    return w, errors, epoch
if __name__ == "__main__":
    X = np.array([[0,0],[0,1],[1,0],[1,1]])
    y = np.array([0,0,0,1])  
    w_init = np.array([10.0, 0.2, -0.75])  

    w_final, errors, epochs = perceptron_train(X, y, w_init)

    print("Final weights:", w_final)
    print("Epochs taken:", epochs)
    print("Final SSE:", errors[-1])

    plt.plot(range(1, len(errors)+1), errors, marker='o')
    plt.xlabel("Epochs")
    plt.ylabel("Sum Squared Error")
    plt.title("AND Gate - Step Activation")
    plt.grid(True)
    plt.show()
