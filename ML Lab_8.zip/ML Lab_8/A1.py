import numpy as np
def summation_unit(x: np.ndarray, w: np.ndarray) -> float:
    return float(np.dot(x, w))
def step_activation(x):
    return np.where(x >= 0, 1.0, 0.0)

def bipolar_step_activation(x):
    return np.where(x >= 0, 1.0, -1.0)

def sigmoid_activation(x):
    z = np.clip(x, -500, 500)
    return 1.0 / (1.0 + np.exp(-z))

def tanh_activation(x):
    return np.tanh(x)

def relu_activation(x):
    return np.maximum(0.0, x)

def leaky_relu_activation(x, alpha=0.01):
    return np.where(x > 0, x, alpha * x)
def sum_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    e = y_true - y_pred
    return float(np.sum(e**2))

if __name__ == "__main__":
    x = np.array([1, 0])
    w = np.array([0.5, -0.3])
    net = summation_unit(x, w)
    out = step_activation(net)
    print("Summation:", net, "Activation output:", out)
