import numpy as np
import matplotlib.pyplot as plt
def summation_unit(x, w): return float(np.dot(x, w))
def step_activation(x): return np.where(x >= 0, 1.0, 0.0)
def sum_squared_error(y_true, y_pred): return float(np.sum((y_true-y_pred)**2))
def add_bias_column(X): return np.hstack([np.ones((X.shape[0],1)), X])

def perceptron_train(X, y, w_init, lr=0.05, max_epochs=1000, convergence_error=0.002):
    Xb = add_bias_column(X); w = w_init.copy(); errors=[]
    for epoch in range(1, max_epochs+1):
        outputs=[]
        for xi,t in zip(Xb,y):
            out = step_activation(summation_unit(xi,w))
            outputs.append(out)
            w += lr*(t-out)*xi
        sse=sum_squared_error(y,np.array(outputs)); errors.append(sse)
        if sse<=convergence_error: break
    return w,errors,epoch

if __name__=="__main__":
    X=np.array([[0,0],[0,1],[1,0],[1,1]]); y=np.array([0,0,0,1])
    w_init=np.array([10.0,0.2,-0.75])
    lrs=[0.1*i for i in range(1,11)]; iters=[]
    for lr in lrs:
        _,_,ep=perceptron_train(X,y,w_init,lr=lr)
        iters.append(ep); print(f"lr={lr} -> epochs={ep}")
    plt.plot(lrs,iters,marker='o'); plt.xlabel("Learning Rate"); plt.ylabel("Epochs")
    plt.title("A4: Learning Rate vs Epochs (AND Gate)"); plt.grid(); plt.show()
