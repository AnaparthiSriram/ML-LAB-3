import numpy as np

def encode_two_output(y):
    y2=np.zeros((len(y),2))
    for i,v in enumerate(y):
        if v==0: y2[i]=[1,0]
        else: y2[i]=[0,1]
    return y2

# reuse mlp_backprop from A8
def sigmoid(x): return 1.0/(1.0+np.exp(-np.clip(x,-500,500)))
def sigmoid_deriv(o): return o*(1-o)
def sum_squared_error(y_true,y_pred): return float(np.sum((y_true-y_pred)**2))
def add_bias(X): return np.hstack([np.ones((X.shape[0],1)),X])

def mlp_backprop(X,y,n_hidden=3,lr=0.05,max_epochs=1000,convergence_error=0.002):
    W1=np.random.randn(n_hidden,X.shape[1]+1)*0.5; W2=np.random.randn(y.shape[1],n_hidden+1)*0.5
    errors=[]
    for epoch in range(1,max_epochs+1):
        Xb=add_bias(X); h_out=sigmoid(Xb.dot(W1.T)); hb=add_bias(h_out)
        o_out=sigmoid(hb.dot(W2.T))
        err=sum_squared_error(y,o_out); errors.append(err)
        if err<=convergence_error: break
        delta_o=(y-o_out)*sigmoid_deriv(o_out); grad_W2=delta_o.T.dot(hb)
        delta_h=delta_o.dot(W2[:,1:])*sigmoid_deriv(h_out); grad_W1=delta_h.T.dot(Xb)
        W2+=lr*grad_W2; W1+=lr*grad_W1
    return W1,W2,errors,epoch

if __name__=="__main__":
    X=np.array([[0,0],[0,1],[1,0],[1,1]]); y=np.array([0,0,0,1])
    y2=encode_two_output(y)
    W1,W2,errs,ep=mlp_backprop(X,y2)
    print("Epochs:",ep,"Final SSE:",errs[-1])
