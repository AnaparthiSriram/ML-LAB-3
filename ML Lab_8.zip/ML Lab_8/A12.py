import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix

if __name__=="__main__":
    df=pd.read_csv("GiveMeSomeCredit.csv").dropna()
    X=df.drop(columns=["SeriousDlqin2yrs"]).select_dtypes(include=["number"]).values
    y=df["SeriousDlqin2yrs"].values
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.25,
                                                   random_state=42,stratify=y)
    scaler=StandardScaler(); X_train=scaler.fit_transform(X_train); X_test=scaler.transform(X_test)
    clf=MLPClassifier(hidden_layer_sizes=(50,),activation='relu',solver='adam',
                      learning_rate_init=0.001,max_iter=500,random_state=42)
    clf.fit(X_train,y_train); preds=clf.predict(X_test)
    print("Train Accuracy:",accuracy_score(y_train,clf.predict(X_train)))
    print("Test Accuracy:",accuracy_score(y_test,preds))
    print("Classification Report:\n",classification_report(y_test,preds,zero_division=0))
    print("Confusion Matrix:\n",confusion_matrix(y_test,preds))
