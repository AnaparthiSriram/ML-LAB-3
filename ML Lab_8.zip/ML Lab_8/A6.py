import numpy as np
import matplotlib.pyplot as plt

def summation_unit(x,w): 
    return float(np.dot(x,w))

def sigmoid_activation(x): 
    return 1.0/(1.0+np.exp(-np.clip(x,-500,500)))

def sum_squared_error(y_true,y_pred): 
    return float(np.sum((y_true-y_pred)**2))

def add_bias_column(X): 
    return np.hstack([np.ones((X.shape[0],1)),X])

def perceptron_sigmoid(X,y,w_init,lr=0.1,max_epochs=1000,convergence_error=0.002):
    Xb=add_bias_column(X)
    w=w_init.copy()
    errors=[]
    for epoch in range(1,max_epochs+1):
        outputs=[]
        for xi,t in zip(Xb,y):
            out=sigmoid_activation(summation_unit(xi,w))
            outputs.append(out)
            w+=lr*(t-out)*xi
        sse=sum_squared_error(y,np.array(outputs))
        errors.append(sse)
        if sse<=convergence_error: break
    return w,errors,epoch

if __name__=="__main__":
    X=np.array([[20,6,2,386],[16,3,6,289],[27,6,2,393],[19,1,2,110],
                [24,4,2,280],[22,1,5,167],[15,4,2,271],[18,4,2,274],
                [21,1,4,148],[16,2,4,198]],dtype=float)
    y=np.array([1,1,1,0,1,0,1,1,0,0],dtype=float)
    X = (X - np.min(X, axis=0)) / (np.ptp(X, axis=0) + 1e-9)

    w_init=np.random.randn(X.shape[1]+1)
    w,errs,ep=perceptron_sigmoid(X,y,w_init)

    print("Final weights:",w)
    print("Epochs:",ep)
    print("Final SSE:",errs[-1])

    plt.plot(range(1,len(errs)+1),errs,marker='o')
    plt.title("A6: Customer Data - Sigmoid Perceptron")
    plt.xlabel("Epochs"); plt.ylabel("SSE")
    plt.grid(True)
    plt.show()
