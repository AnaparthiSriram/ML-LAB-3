import numpy as np
import matplotlib.pyplot as plt

def summation_unit(x,w): return float(np.dot(x,w))
def step_activation(x): return np.where(x>=0,1.0,0.0)
def sum_squared_error(y_true,y_pred): return float(np.sum((y_true-y_pred)**2))
def add_bias_column(X): return np.hstack([np.ones((X.shape[0],1)),X])

def perceptron_train(X,y,w_init,lr=0.05,max_epochs=1000,convergence_error=0.002):
    Xb=add_bias_column(X); w=w_init.copy(); errors=[]
    for epoch in range(1,max_epochs+1):
        outputs=[]
        for xi,t in zip(Xb,y):
            out=step_activation(summation_unit(xi,w))
            outputs.append(out); w+=lr*(t-out)*xi
        sse=sum_squared_error(y,np.array(outputs)); errors.append(sse)
        if sse<=convergence_error: break
    return w,errors,epoch

if __name__=="__main__":
    X=np.array([[0,0],[0,1],[1,0],[1,1]]); y=np.array([0,1,1,0])
    w_init=np.zeros(3)
    w,errs,ep=perceptron_train(X,y,w_init,lr=0.05)
    print("Final weights:",w,"Epochs:",ep,"Final SSE:",errs[-1])
    plt.plot(range(1,len(errs)+1),errs,marker='o')
    plt.title("A5: XOR Gate - Perceptron (Non-convergence expected)")
    plt.xlabel("Epochs"); plt.ylabel("SSE"); plt.grid(); plt.show()
