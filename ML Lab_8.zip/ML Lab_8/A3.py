import numpy as np

def summation_unit(x: np.ndarray, w: np.ndarray) -> float:
    return float(np.dot(x, w))

def bipolar_step_activation(x):
    return np.where(x >= 0, 1.0, -1.0)

def sigmoid_activation(x):
    z = np.clip(x, -500, 500) 
    return 1.0 / (1.0 + np.exp(-z))

def relu_activation(x):
    return np.maximum(0.0, x)

def sum_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    e = y_true - y_pred
    return float(np.sum(e**2))

def perceptron_train_activation(X, y, w_init, lr, activation="step", 
                                max_epochs=1000, convergence_error=0.002):
    Xb = np.hstack([np.ones((X.shape[0],1)), X])
    w = w_init.copy()
    errors = []
    act_func = {"bipolar": bipolar_step_activation,
                "sigmoid": sigmoid_activation,
                "relu": relu_activation}[activation]

    for epoch in range(1, max_epochs+1):
        outputs = []
        for xi, target in zip(Xb, y):
            net = summation_unit(xi, w)
            out = act_func(net)
            outputs.append(out)
            w += lr * (target - out) * xi
        sse = sum_squared_error(y, np.array(outputs))
        errors.append(sse)
        if sse <= convergence_error:
            break
    return w, errors, epoch

if __name__ == "__main__":
    X = np.array([[0,0],[0,1],[1,0],[1,1]])
    y = np.array([0,0,0,1])  
    w_init = np.array([10.0, 0.2, -0.75])

    for act in ["bipolar", "sigmoid", "relu"]:
        y_mod = np.where(y==0, -1, 1) if act=="bipolar" else y
        w, errs, ep = perceptron_train_activation(X, y_mod, w_init, 0.05, act)
        print(act, "-> epochs:", ep, "final SSE:", errs[-1])
