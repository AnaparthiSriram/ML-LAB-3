import numpy as np

def sigmoid_activation(x): 
    return 1.0/(1.0+np.exp(-np.clip(x,-500,500)))

def add_bias_column(X): 
    return np.hstack([np.ones((X.shape[0],1)),X])

def pseudo_inverse_solution(X,y):
    return np.linalg.pinv(add_bias_column(X)).dot(y)

if __name__=="__main__":
    X=np.array([[20,6,2,386],[16,3,6,289],[27,6,2,393],[19,1,2,110],
                [24,4,2,280],[22,1,5,167],[15,4,2,271],[18,4,2,274],
                [21,1,4,148],[16,2,4,198]],dtype=float)
    y=np.array([1,1,1,0,1,0,1,1,0,0],dtype=float)

    # ✅ Use np.min and np.ptp for NumPy 2.0 compatibility
    X = (X - np.min(X, axis=0)) / (np.ptp(X, axis=0) + 1e-9)

    w = pseudo_inverse_solution(X,y)
    preds = (sigmoid_activation(add_bias_column(X).dot(w)) >= 0.5).astype(int)
    acc = (preds == y).mean()

    print("Pseudo-inverse Weights:", w)
    print("Predictions:", preds)
    print("True Labels:", y.astype(int))
    print("Accuracy:", acc)
