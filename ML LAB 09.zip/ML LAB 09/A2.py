# A2.py - Pipeline Implementation (Optimized for Speed)
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

def load_data(path="GiveMeSomeCredit.csv"):
    df = pd.read_csv(path)
    X = df.drop("SeriousDlqin2yrs", axis=1)
    y = df["SeriousDlqin2yrs"]
    return X, y

def build_pipeline():
    pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", RandomForestClassifier(
            n_estimators=50,    # reduce trees
            max_depth=10,       # limit depth for speed
            n_jobs=-1,          # parallelize
            random_state=42
        ))
    ])
    return pipeline

if __name__ == "__main__":
    X, y = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    pipeline = build_pipeline()
    print("Training pipeline... please wait")
    pipeline.fit(X_train, y_train)

    y_pred = pipeline.predict(X_test)

    print("\n--- A2: Pipeline Results ---")
    print(classification_report(y_test, y_pred))
    print("Accuracy:", accuracy_score(y_test, y_pred))
