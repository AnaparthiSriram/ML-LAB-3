import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
import lime.lime_tabular

def load_data(path="GiveMeSomeCredit.csv"):
    df = pd.read_csv(path)
    X = df.drop("SeriousDlqin2yrs", axis=1)
    y = df["SeriousDlqin2yrs"]
    return X, y

def build_pipeline():
    pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", RandomForestClassifier(
            n_estimators=50, max_depth=10, n_jobs=-1, random_state=42
        ))
    ])
    return pipeline

if __name__ == "__main__":
    X, y = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Fit pipeline
    pipeline = build_pipeline()
    print("Training pipeline...")
    pipeline.fit(X_train, y_train)

    # ---- FIX: preprocess data for LIME (no NaNs) ----
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    X_train_proc = scaler.fit_transform(imputer.fit_transform(X_train))
    X_test_proc = scaler.transform(imputer.transform(X_test))

    # Build explainer on processed training data
    explainer = lime.lime_tabular.LimeTabularExplainer(
        training_data=X_train_proc,
        feature_names=X.columns.tolist(),
        class_names=["No Default", "Default"],
        mode="classification",
        discretize_continuous=False
    )

    # Pick a test instance (already imputed + scaled)
    i = 5
    exp = explainer.explain_instance(
        data_row=X_test_proc[i],
        predict_fn=pipeline.predict_proba
    )

    exp.save_to_file("lime_explanation.html")
    print("\n--- A3: LIME explanation saved to lime_explanation.html ---")
