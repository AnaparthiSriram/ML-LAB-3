# A1.py - Faster Stacking Classifier Implementation
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline

def load_data(path="GiveMeSomeCredit.csv"):
    df = pd.read_csv(path)
    X = df.drop("SeriousDlqin2yrs", axis=1)
    y = df["SeriousDlqin2yrs"]
    return X, y

def build_stacking_classifier():
    base_learners = [
        ("rf", RandomForestClassifier(n_estimators=50, n_jobs=-1, random_state=42)),
        ("gb", GradientBoostingClassifier(n_estimators=50, random_state=42))
    ]
    meta_learner = LogisticRegression(max_iter=500, solver="lbfgs")
    stacking_clf = StackingClassifier(
        estimators=base_learners,
        final_estimator=meta_learner,
        cv=3,                 # reduce folds from 5 → 3
        n_jobs=-1,            # use all CPU cores
        passthrough=False     # keep it lighter
    )
    return stacking_clf

if __name__ == "__main__":
    X, y = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("stacking", build_stacking_classifier())
    ])

    print("Training the stacking classifier... please wait")
    pipeline.fit(X_train, y_train)

    y_pred = pipeline.predict(X_test)

    print("\n--- A1: Stacking Classifier Results ---")
    print(classification_report(y_test, y_pred))
    print("Accuracy:", accuracy_score(y_test, y_pred))
